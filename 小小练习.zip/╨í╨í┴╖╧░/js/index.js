$(function(){
    var imgAll =$("#why .benefit img");
    var i =0;
    var k = 0;
    setInterval(function(){
       $(".bigPicture-bg li").eq(1).fadeToggle(1000);
    },5000);
    //课程图的滚动
    /*监听滚动条的位置*/
    $(window).scroll(function(){
        if($("html,body").scrollTop()>50){
            $(".product1").animate({
                left:"0%"
            },1500)
        }
        if ($("html,body").scrollTop()>100){
            $(".product2").animate({
                left:"0%"
            },1500)
        }
        if($("html,body").scrollTop()>230){
            $(".product3").animate({
                left:"0%"
            },1500)
        }
        //信息滚动
        if($("html,body").scrollTop()>1722){
            $(".message .content").animate({
                top: "0%",
                opacity: 1
            },1000);
        }
        if($("html,body").scrollTop()>2450){
            $(".promise3").addClass("rotate");
            $(".promise2").addClass("rotate");
            $(".promise1").addClass("rotate");
        }
        if($("html,body").scrollTop()>3300){
            var timer = setInterval(function(){
                if(i>imgAll.length){
                    clearInterval(timer);
                    i=0;
                }else{
                    imgAll.eq(i).addClass("show");
                }
                i++;
            },700);
        }
        if($("html,body").scrollTop()>4000){
           $(".teacher1").stop().animate({
               width: 220+"px"
           },1000,function(){
               $(this).stop().animate({
                   width:200+"px"
               },1000)
           });
        }
        if($("html,body").scrollTop()>4300){
            $(".teacher2").stop().animate({
                width: 220+"px"
            },1000,function(){
                $(this).stop().animate({
                    width:200+"px"
                },1000)
            });
        }
        if($("html,body").scrollTop()>4600){
            $(".teacher3").stop().animate({
                width: 220+"px"
            },1000,function(){
                $(this).stop().animate({
                    width:200+"px"
                },1000)
            });
        }
        if($("html,body").scrollTop()>5000){
            var timer =setInterval(function(){
                if(k>=$("#campus ul").length){
                    clearInterval(timer);
                    k=0;
                }else{
                    $("#campus ul").eq(k).find(".text").addClass("animation");
                    $("#campus ul").eq(k).siblings().find(".text").removeClass("animation");
                }
                ++k;
                console.log(k);
            },2500);

        }
    })
    //锚点 到 校区
    $(".phone").find("a").on("click",function(){
        $("html,body").stop().animate({
           scrollTop: 5325+"px"
        },1000);
    });
    //关闭QQ交谈
    $("#QQspace .top a").on("click",function(){
        $("#QQspace").fadeOut(500);
    })
    //打开qq交谈
    $("#rightNav .qq a").on("click",function(){
        $("#QQspace").fadeIn(500);
    })
    //返回顶部
    $("#rightNav .top a").on("click",function(){
        $("html,body").stop().animate({
            scrollTop:0+"px"
        },1000);
    })
    //关闭视频预约
    $("#videoChat a").on("click",function(){
        $("#videoChat").stop().slideUp(1000);
    })
    //打开视频预约
    $(".order").on("click",function(){
        $("#videoChat").stop().slideDown(1000);
    })


});